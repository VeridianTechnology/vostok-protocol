import { motion } from "framer-motion";
import { useState } from "react";

const specs = [
  {
    category: "Skin Clarity",
    before: { value: "62%", detail: "Uneven tone, visible texture" },
    method: "Bioactive resurfacing protocol",
    after: { value: "99%", detail: "Luminous, refined surface" },
  },
  {
    category: "Jawline Definition",
    before: { value: "0.54", detail: "Soft contour, undefined angles" },
    method: "Structural contouring framework",
    after: { value: "0.92", detail: "Sculpted, precise geometry" },
  },
  {
    category: "Facial Symmetry",
    before: { value: "0.61", detail: "Noticeable asymmetry" },
    method: "Bilateral alignment system",
    after: { value: "0.78", detail: "Harmonized proportions" },
  },
  {
    category: "Skin Hydration",
    before: { value: "38%", detail: "Dehydrated, dull appearance" },
    method: "Deep moisture engineering",
    after: { value: "94%", detail: "Plump, dewy resilience" },
  },
  {
    category: "Pore Refinement",
    before: { value: "2.4mm", detail: "Enlarged, visible pores" },
    method: "Micro-texture optimization",
    after: { value: "0.8mm", detail: "Near-invisible refinement" },
  },
];

const SpecComparison = () => {
  const [chapterIndex, setChapterIndex] = useState(0);
  const chapterPages = [
    "/Sections/1_page-0001.jpg",
    "/Sections/2_page-0001.jpg",
    "/Sections/3_page-0001.jpg",
    "/Sections/4_page-0001.jpg",
    "/Sections/5_page-0001.jpg",
    "/Sections/6_page-0001.jpg",
    "/Sections/7_page-0001.jpg",
    "/Sections/8_page-0001.jpg",
    "/Sections/9_page-0001.jpg",
    "/Sections/10_page-0001.jpg",
  ];
  const activeChapter = chapterPages[chapterIndex];

  return (
    <section className="py-24 px-6 gradient-chrome">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-chrome tracking-[0.4em] uppercase text-xs mb-4 font-light">
            Technical Specifications
          </p>
          <h2 className="text-3xl md:text-4xl font-light text-foreground tracking-tight">
            Performance <span className="font-semibold">Analysis</span>
          </h2>
        </motion.div>

        {/* Header */}
        <div className="grid grid-cols-3 gap-4 mb-4 px-4">
          <p className="text-xs tracking-[0.3em] uppercase text-steel text-center">Before</p>
          <p className="text-xs tracking-[0.3em] uppercase text-warm text-center">Method</p>
          <p className="text-xs tracking-[0.3em] uppercase text-foreground text-center">After</p>
        </div>

        <div className="divider-line mb-6" />

        {/* Spec rows */}
        <div className="space-y-1">
          {specs.map((spec, index) => (
            <motion.div
              key={spec.category}
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
            >
              <div className="gradient-spec-card rounded-sm p-5 md:p-6 border border-chrome/5">
                <p className="text-[10px] tracking-[0.3em] uppercase text-chrome mb-3 text-center">
                  {spec.category}
                </p>
                <div className="grid grid-cols-3 gap-4 items-center">
                  {/* Before */}
                  <div className="text-center">
                    <p className="text-xl md:text-2xl font-light text-steel">{spec.before.value}</p>
                    <p className="text-[10px] text-steel/60 mt-1 font-light">{spec.before.detail}</p>
                  </div>

                  {/* Method */}
                  <div className="text-center flex flex-col items-center">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="w-6 h-px bg-chrome/20" />
                      <span className="w-1.5 h-1.5 rounded-full bg-warm/60" />
                      <span className="w-6 h-px bg-chrome/20" />
                    </div>
                    <p className="text-[10px] text-chrome font-light leading-tight">{spec.method}</p>
                  </div>

                  {/* After */}
                  <div className="text-center">
                    <p className="text-xl md:text-2xl font-semibold text-foreground">{spec.after.value}</p>
                    <p className="text-[10px] text-chrome mt-1 font-light">{spec.after.detail}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-12 rounded-2xl border border-chrome/10 bg-black/30 px-6 pb-6 pt-8">
          <p className="text-[12px] uppercase tracking-[0.3em] text-chrome/70 mb-3 text-center">
            Chapter Preview
          </p>
          <div className="relative overflow-hidden rounded-xl border border-white/10 bg-black/40">
            <motion.img
              key={chapterIndex}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.8 }}
              src={activeChapter}
              alt={`Chapter preview ${chapterIndex + 1}`}
              className="w-full object-cover"
              loading="lazy"
            />
          </div>
          <div className="mt-4 flex items-center justify-between text-[11px] uppercase tracking-[0.3em] text-chrome/70">
            <button
              type="button"
              onClick={() =>
                setChapterIndex(
                  (current) => (current - 1 + chapterPages.length) % chapterPages.length
                )
              }
              className="rounded-full border border-white/10 px-3 py-2 transition-colors duration-300 hover:text-foreground"
            >
              Prev
            </button>
            <span>
              {String(chapterIndex + 1).padStart(2, "0")} /{" "}
              {String(chapterPages.length).padStart(2, "0")}
            </span>
            <button
              type="button"
              onClick={() => setChapterIndex((current) => (current + 1) % chapterPages.length)}
              className="rounded-full border border-white/10 px-3 py-2 transition-colors duration-300 hover:text-foreground"
            >
              Next
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SpecComparison;
